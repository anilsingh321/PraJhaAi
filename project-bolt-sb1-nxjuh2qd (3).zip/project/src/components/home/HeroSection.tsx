import React from 'react';
import SearchBar from '../ui/SearchBar';

const HeroSection: React.FC = () => {
  return (
    <div className="relative min-h-[85vh] flex items-center">
      {/* Animated tech background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg')] bg-cover bg-center opacity-40">
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/70 to-slate-950" />
        </div>
        
        {/* Floating tech elements */}
        <div className="absolute inset-0">
          <div className="absolute top-[10%] left-[15%] animate-float-slow">
            <img 
              src="https://images.pexels.com/photos/8386423/pexels-photo-8386423.jpeg" 
              alt="" 
              className="w-24 h-24 rounded-xl opacity-70"
            />
          </div>
          <div className="absolute top-[20%] right-[20%] animate-float-medium">
            <img 
              src="https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg" 
              alt="" 
              className="w-32 h-32 rounded-xl opacity-60"
            />
          </div>
          <div className="absolute top-[40%] left-[25%] animate-float-fast">
            <img 
              src="https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg" 
              alt="" 
              className="w-20 h-20 rounded-xl opacity-50"
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold mb-6 leading-tight">
          <span className="block">Discover the Best</span>
          <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 text-transparent bg-clip-text">
            AI Tools
          </span>
        </h1>
        
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Your centralized hub to find all trending and cutting-edge AI tools across various categories.
        </p>
        
        <div className="max-w-xl mx-auto mb-12">
          <SearchBar />
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 text-sm">
          <span className="text-gray-400">Popular:</span>
          <a href="#" className="text-cyan-400 hover:underline">Image Generation</a>
          <a href="#" className="text-cyan-400 hover:underline">Video Editing</a>
          <a href="#" className="text-cyan-400 hover:underline">Code Assistance</a>
          <a href="#" className="text-cyan-400 hover:underline">Productivity</a>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;