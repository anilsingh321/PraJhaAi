import React, { useState } from 'react';
import { Send } from 'lucide-react';

const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to a newsletter service
    console.log('Subscribing email:', email);
    setIsSubmitted(true);
    setEmail('');
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-4xl mx-auto bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 md:p-12 shadow-xl border border-slate-700">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4 text-white">
            Stay Updated with AI Innovations
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Subscribe to our newsletter and be the first to know about new AI tools, 
            exclusive guides, and industry insights.
          </p>
        </div>

        {isSubmitted ? (
          <div className="text-center p-4 bg-green-500/20 border border-green-500/40 rounded-lg">
            <p className="text-green-400">
              Thanks for subscribing! Check your email to confirm your subscription.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-grow bg-slate-700/50 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:opacity-90 text-white px-6 py-3 rounded-lg flex items-center justify-center"
              >
                Subscribe
                <Send className="h-4 w-4 ml-2" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Newsletter;