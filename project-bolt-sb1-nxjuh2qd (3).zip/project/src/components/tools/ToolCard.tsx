import React from 'react';
import { ExternalLink, Star, Heart } from 'lucide-react';
import { Tool } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Link } from '../ui/Link';

interface ToolCardProps {
  tool: Tool;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <Card className="h-full flex flex-col group">
      <div className="relative">
        <img
          src={tool.logo}
          alt={`${tool.name} logo`}
          className="w-full h-48 object-cover object-center"
        />
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-slate-900/90" />
        
        {tool.featured && (
          <div className="absolute top-3 left-3">
            <Badge color="warning">Featured</Badge>
          </div>
        )}
        
        {tool.isNew && (
          <div className="absolute top-3 right-3">
            <Badge color="success">New</Badge>
          </div>
        )}
      </div>
      
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
            {tool.name}
          </h3>
          <div className="flex items-center text-amber-400">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 text-sm">{tool.popularity.toFixed(1)}</span>
          </div>
        </div>
        
        <p className="text-gray-400 mb-4 flex-grow">{tool.description}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge color="primary">{tool.category}</Badge>
          <Badge>{tool.pricingType}</Badge>
        </div>
        
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>Launched: {formatDate(tool.launchDate)}</span>
        </div>
      </div>
      
      <div className="p-4 border-t border-slate-700 flex justify-between">
        <button className="text-gray-400 hover:text-pink-500 transition-colors">
          <Heart className="h-5 w-5" />
        </button>
        <Link
          href={tool.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-full hover:opacity-90 transition text-sm"
        >
          Visit Tool <ExternalLink className="h-4 w-4 ml-1" />
        </Link>
      </div>
    </Card>
  );
};

export default ToolCard;