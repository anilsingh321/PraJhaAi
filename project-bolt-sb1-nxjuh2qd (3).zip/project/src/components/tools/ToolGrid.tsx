import React from 'react';
import ToolCard from './ToolCard';
import { Tool } from '../../types';

interface ToolGridProps {
  tools: Tool[];
  title?: string;
  description?: string;
}

const ToolGrid: React.FC<ToolGridProps> = ({ tools, title, description }) => {
  return (
    <div className="container mx-auto px-4 py-12">
      {title && (
        <h2 className="text-3xl font-bold mb-2 text-white">{title}</h2>
      )}
      {description && (
        <p className="text-gray-400 mb-8 max-w-2xl">{description}</p>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {tools.map((tool) => (
          <ToolCard key={tool.id} tool={tool} />
        ))}
      </div>
    </div>
  );
};

export default ToolGrid;