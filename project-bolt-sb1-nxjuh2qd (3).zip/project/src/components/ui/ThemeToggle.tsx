import React, { useState, useEffect } from 'react';
import { Moon, Sun } from 'lucide-react';

const ThemeToggle: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);

  // For demo purposes, we'll start with dark mode
  // In a real implementation, this would check system preferences and saved settings
  useEffect(() => {
    // Our site already uses dark mode by default in this implementation
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    // In a full implementation, this would toggle document class and save preference
  };

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-full hover:bg-slate-800 transition"
      aria-label="Toggle theme"
    >
      {isDarkMode ? (
        <Moon className="h-5 w-5 text-cyan-400" />
      ) : (
        <Sun className="h-5 w-5 text-yellow-400" />
      )}
    </button>
  );
};

export default ThemeToggle;