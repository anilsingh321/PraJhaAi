import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { mockTools } from '../../data/mockData';
import { Tool } from '../../types';

interface SearchBarProps {
  className?: string;
  compact?: boolean;
}

const SearchBar: React.FC<SearchBarProps> = ({ className = '', compact = false }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Tool[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (term.trim().length > 0) {
      setIsSearching(true);
      const results = mockTools.filter(tool => 
        tool.name.toLowerCase().includes(term.toLowerCase()) ||
        tool.description.toLowerCase().includes(term.toLowerCase()) ||
        tool.tags.some(tag => tag.toLowerCase().includes(term.toLowerCase())) ||
        tool.category.toLowerCase().includes(term.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setIsSearching(false);
      setSearchResults([]);
    }
  };

  return (
    <div className={`relative ${className}`}>
      <div className={`flex items-center bg-slate-800/70 ${compact ? 'w-48 lg:w-64' : 'w-full max-w-xl'} rounded-full overflow-hidden border border-slate-700 focus-within:border-cyan-500 transition-all duration-300`}>
        <input
          type="text"
          placeholder="Search AI tools..."
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="bg-transparent text-white w-full py-2 px-4 focus:outline-none placeholder-gray-500"
        />
        <button
          type="button"
          className="p-2 mr-1 text-gray-400 hover:text-cyan-400 transition-colors"
        >
          <Search className="h-5 w-5" />
        </button>
      </div>

      {/* Search Results Dropdown */}
      {isSearching && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
          {searchResults.length > 0 ? (
            searchResults.map((tool) => (
              <a
                key={tool.id}
                href={tool.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start p-4 hover:bg-slate-700/50 transition-colors border-b border-slate-700 last:border-0"
              >
                <div>
                  <h3 className="text-white font-medium">{tool.name}</h3>
                  <p className="text-sm text-gray-400 mt-1">{tool.description}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {tool.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-2 py-1 bg-slate-700 text-cyan-400 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </a>
            ))
          ) : (
            <div className="p-4 text-center text-gray-400">
              No tools found matching "{searchTerm}"
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchBar;