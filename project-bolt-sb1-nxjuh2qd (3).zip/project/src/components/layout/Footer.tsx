import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Twitter, Linkedin, Mail, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-gray-300">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">PrajhaAI</h3>
            <p className="text-gray-400 mb-4">
              Your one-stop destination for discovering the best AI tools across various categories.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition">
                <Github className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Categories</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/categories/ai-assistant" className="text-gray-400 hover:text-cyan-400 transition">
                  AI Assistants
                </Link>
              </li>
              <li>
                <Link to="/categories/writing" className="text-gray-400 hover:text-cyan-400 transition">
                  Writing & Content
                </Link>
              </li>
              <li>
                <Link to="/categories/design" className="text-gray-400 hover:text-cyan-400 transition">
                  Design & Creativity
                </Link>
              </li>
              <li>
                <Link to="/categories/developer" className="text-gray-400 hover:text-cyan-400 transition">
                  Developer Tools
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Resources</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/blog" className="text-gray-400 hover:text-cyan-400 transition">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/newsletter" className="text-gray-400 hover:text-cyan-400 transition">
                  Newsletter
                </Link>
              </li>
              <li>
                <Link to="/submit" className="text-gray-400 hover:text-cyan-400 transition">
                  Submit a Tool
                </Link>
              </li>
              <li>
                <Link to="/roadmap" className="text-gray-400 hover:text-cyan-400 transition">
                  Roadmap
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4 text-white">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-cyan-400" />
                <a href="tel:8144082470" className="text-gray-400 hover:text-cyan-400 transition">
                  +91 814 408 2470
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-cyan-400" />
                <a href="mailto:singanil456@gmail.com" className="text-gray-400 hover:text-cyan-400 transition break-all">
                  singanil456@gmail.com
                </a>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-400 hover:text-cyan-400 transition">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-400 hover:text-cyan-400 transition">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} PrajhaAI. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;