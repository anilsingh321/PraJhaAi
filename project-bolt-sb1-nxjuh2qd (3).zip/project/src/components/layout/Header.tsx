import React, { useState, useEffect } from 'react';
import { Search, Menu, X, Moon, Sun, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import ThemeToggle from '../ui/ThemeToggle';
import SearchBar from '../ui/SearchBar';
import AuthModal from '../auth/AuthModal';
import { useAuthStore } from '../../store/authStore';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const { user, signOut } = useAuthStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-slate-900/95 backdrop-blur-md shadow-md'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 text-transparent bg-clip-text">
            PrajhaAI
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/categories/ai-assistant" className="text-gray-300 hover:text-cyan-400 transition">
            AI Assistants
          </Link>
          <Link to="/categories/writing" className="text-gray-300 hover:text-cyan-400 transition">
            Writing
          </Link>
          <Link to="/categories/design" className="text-gray-300 hover:text-cyan-400 transition">
            Design
          </Link>
          <Link to="/categories/video" className="text-gray-300 hover:text-cyan-400 transition">
            Video
          </Link>
          <Link to="/categories/developer" className="text-gray-300 hover:text-cyan-400 transition">
            Developer
          </Link>
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          <SearchBar className="hidden lg:flex" compact />
          <ThemeToggle />
          {user ? (
            <div className="flex items-center space-x-4">
              <span className="text-gray-300">{user.email}</span>
              <button
                onClick={() => signOut()}
                className="flex items-center space-x-2 text-gray-300 hover:text-cyan-400"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="px-4 py-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:opacity-90 transition"
            >
              Sign In
            </button>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center space-x-3 md:hidden">
          <ThemeToggle />
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-gray-300 hover:text-white transition"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-slate-900/95 backdrop-blur-md">
          <div className="container mx-auto px-4 py-4">
            <SearchBar className="mb-4" />
            <nav className="flex flex-col space-y-4">
              <Link to="/categories/ai-assistant" className="text-gray-300 hover:text-cyan-400 transition py-2">
                AI Assistants
              </Link>
              <Link to="/categories/writing" className="text-gray-300 hover:text-cyan-400 transition py-2">
                Writing
              </Link>
              <Link to="/categories/design" className="text-gray-300 hover:text-cyan-400 transition py-2">
                Design
              </Link>
              <Link to="/categories/video" className="text-gray-300 hover:text-cyan-400 transition py-2">
                Video
              </Link>
              <Link to="/categories/developer" className="text-gray-300 hover:text-cyan-400 transition py-2">
                Developer
              </Link>
              {user ? (
                <button
                  onClick={() => signOut()}
                  className="flex items-center space-x-2 text-gray-300 hover:text-cyan-400 py-2"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sign Out</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    setIsAuthModalOpen(true);
                    setIsMenuOpen(false);
                  }}
                  className="py-2 px-4 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:opacity-90 transition text-center"
                >
                  Sign In
                </button>
              )}
            </nav>
          </div>
        </div>
      )}

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </header>
  );
};

export default Header;