export interface Tool {
  id: string;
  name: string;
  description: string;
  logo: string;
  category: CategoryType;
  tags: string[];
  launchDate: string;
  popularity: number;
  pricingType: 'Free' | 'Paid' | 'Freemium';
  url: string;
  featured?: boolean;
  isNew?: boolean;
}

export type CategoryType = 
  | 'ai-assistant'
  | 'writing'
  | 'design'
  | 'video'
  | 'productivity'
  | 'developer'
  | 'research'
  | 'marketing';

export interface Category {
  id: CategoryType;
  name: string;
  description: string;
  icon: string;
  count: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  favorites: string[];
}