import React from 'react';
import { useNavigate } from 'react-router-dom';
import HeroSection from '../components/home/HeroSection';
import CategorySection from '../components/home/CategorySection';
import FeaturedSection from '../components/home/FeaturedSection';
import NewToolsSection from '../components/home/NewToolsSection';
import Newsletter from '../components/home/Newsletter';
import { mockTools, categories } from '../data/mockData';
import { useAuthStore } from '../store/authStore';

const Home: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();

  const handleCategoryClick = (categoryId: string) => {
    navigate(`/categories/${categoryId}`);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div>
      <HeroSection />
      <CategorySection 
        categories={categories} 
        onCategoryClick={handleCategoryClick}
        isAuthenticated={isAuthenticated}
      />
      <FeaturedSection tools={mockTools} />
      <NewToolsSection tools={mockTools} />
      <Newsletter />
    </div>
  );
};

export default Home;